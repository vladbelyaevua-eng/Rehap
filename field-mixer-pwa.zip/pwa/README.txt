FIELD MIXER (PWA)
1. Завантажте всю папку на будь-який HTTPS-хостинг (Netlify Drop, GitHub Pages, Cloudflare Pages).
2. iPhone: відкрийте адресу в Safari -> Поділитися -> На екран "Додому".
3. Android: відкрийте в Chrome -> меню -> Встановити застосунок.
